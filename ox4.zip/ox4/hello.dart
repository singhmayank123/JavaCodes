void main(){
	var laugh_symbol = '\u{1f600}';  
    print(laugh_symbol);  
}