
import java.util.Arrays;
public class Main
{
    public static void main(String[] args){
      
      Object[] array = new Object[5];

        array[0] = "Mayank";
        array[1] = "Suraj";
        array[2] = "amit";
        array[3] = "deepa";
        array[4] = "Mayan";

        Object[] newArr = Arrays.copyOf(array, array.length);
        
        System.out.println(Arrays.toString(newArr));
    }

    public boolean equals(Object o){

        if(o instanceof YourListClassName){

            Node<T> current = head;

            if(isEmpty() || o.isEmpty())
                throw new EmptyCollectionException("List");
        }
    }

}
