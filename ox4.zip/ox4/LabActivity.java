/* observed by the teacher and assigns a numeric score */
public class LabActivity extends GradedActivity{

	public LabActivity(double numericScore){
		setScore(numericScore);
	}
}
