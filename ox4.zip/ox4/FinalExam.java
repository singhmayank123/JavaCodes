/* This is a sub-class that extends the GradedActivity class */

public class FinalExam extends GradedActivity{

/** A constructor that takes a score and calls the setScore 
 * method to set the private score variable in the super class */
	public FinalExam(double score){
		setScore(score);
	}
}
