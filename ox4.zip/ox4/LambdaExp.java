
interface Test{
	int apply(int a, int b);
}

public class LambdaExp
{

	public static void main(String[] args) {
		
		
	}	
}