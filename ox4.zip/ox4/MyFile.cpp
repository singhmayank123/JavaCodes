





#include<iostream>
using namespace std; 
int main(){ }
#include<iostream>
using namespace std; 
int main(){ }
#include<iostream>
using namespace std; 
int main(){ }
#include<iostream>
using namespace std; 
int main(){ }
#include<iostream>
using namespace std; 
int main(){ }
#include<iostream>
using namespace std; 
int main(){ }
#include<iostream>
using namespace std; 
int main(){ }
#include<iostream>
using namespace std; 
int main(){ }
